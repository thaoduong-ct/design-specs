# Handoff bundle — DSW-1695 Rewards Per-Quest Join Gate

**Link review prototype (Builder OS, nội bộ Chợ Tốt):** https://arts.builderos.space/d/6d2f56cc8b19b2410460c9032ae4a111bc8b28825042ba055a041061f36ec57e/dsw-1695-quest-join-gate-prototype.html

- `designspec-rewards-quest-join-gate.md` — spec chính (đọc file này trước)
- `assets/` — asset dùng trong spec (Loại B: diem-tot.svg, icon-back.svg; Loại C: quest-*.png, g*.svg là dữ liệu demo)
- `prototype/prototype.html` — prototype tương tác (bấm "Tham gia", giả lập lỗi API, bật/tắt requires_join, event log)
- `prototype/mockup.html` — 3 state tĩnh: Chưa tham gia / Lỗi / Đã tham gia

Mở file HTML qua một local server (vd `python3 -m http.server`) để asset load đúng.
Nguồn UI: Figma "Revenue Handoff • 2026" node 8775:41778 / 8776:42074 · PRD: IDEA-jq81.
