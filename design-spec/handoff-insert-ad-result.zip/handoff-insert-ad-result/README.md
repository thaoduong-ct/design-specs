# Handoff — Unified Insert-Ad Result Screen (PTY + JOB · App + Desktop)

Đọc file này trước. Spec chính: `designspec-insert-ad-result.md`.

## CÒN THIẾU — đọc trước khi build

Không có mục nào chặn build. Các mục dưới đây cần chốt trước QC (chi tiết: bảng Open Items trong spec):

| # | Thiếu gì | Chặn ai | Owner |
|---|---|---|---|
| 1 | JOB New nhánh (1→3): Voucher → Bí kíp, không có Upsell (lệch AC-01) — xác nhận chủ ý thử nghiệm | logic nhánh JOB | PM |
| 2 | Truyền list_id / ad_id vào card video / xác thực (link Edit Ad đã có — Open Risk 46) | CTA 2 card | Eng-lead |
| 3 | Visual chính thức của "Xem tất cả" (luôn đi kèm danh sách voucher JOB) | UI danh sách voucher | Thảo Dương |
| 4 | Ảnh + nội dung sheet cho Tin ưu tiên, Gói Hiển Thị Tối Ưu, Gói Hiển Thị Tăng Cường — prototype đang dùng placeholder | sheet của 3 gói | Thảo Dương |
| 5 | Tên DS của icon `Star-fill` và token màu icon (#222222) | icon | Thắng Phạm |
| 6 | PRD: sửa AC-04 (mâu thuẫn AC-EC-07); bổ sung skeleton, nhãn "Miễn phí", thẻ tin mở sẵn, chạm mã đơn | tài liệu | PM |
| 7 | Field API cho voucher row, thumbnail Cross-Post, số liệu video, {n} + avatar nhà tuyển dụng | dữ liệu widget | Eng-lead |
| 8 | Event cho nút "Bán nhanh hơn" / "Tuyển nhanh hơn" (đích đã chốt: POS Premium Feature) | tracking | PM / Data |
| 9 | Visual nhãn "Giảm giá" trên gói không nổi bật | nhãn gói JOB | Thảo Dương |
| 10 | Figma cập nhật theo spec v3 | đối chiếu QC | Thảo Dương |

**Spec v3 (2026-10-08, theo PRD 07/10):** JOB chọn khối theo nhánh A/B (AC-14) · gói JOB nổi bật = hạng kế trên hạng hiện tại, nhãn "Đề xuất"; gói giảm giá có "Giảm giá"; bỏ "Phổ biến" · dòng cạnh tranh "Có {n} nhà tuyển dụng khác cũng đang tuyển {job type} tại Hồ Chí Minh" + avatar dưới tiêu đề, chỉ tin ở HCM · danh sách voucher luôn có "Xem tất cả", {n} = số voucher thật · empty state → POS Premium Feature · đủ link app/web cho mọi CTA.

**Spec v2:** thứ tự khối PTY theo AC-15 · luật voucher §5.6 · empty state lỗi API, skeleton, placeholder 3 sheet · Free-Entitlement PTY = Casual.

Asset: đủ. Không có minh hoạ nào cần export thêm (thumbnail chồng ảnh trong widget dựng ở runtime từ ảnh tin thật). `widget-bikip-image.png` chỉ 154×154 — nên xin bản lớn hơn cho màn @3x.

## Gói có gì

```
handoff-insert-ad-result/
├── README.md                          ← file này
├── designspec-insert-ad-result.md     ← spec chính (layout YAML, token, rule, edge case, tagging)
├── assets/                            ← asset production (Loại B) — tên file khớp bảng Assets trong spec
│   └── icons/                         ← SVG icon DS chỉ để đối chiếu; build dùng DS icon library
├── demo/                              ← dữ liệu mẫu (Loại C) — KHÔNG dùng trong production
└── prototype/
    ├── index.html + app.js + assets/  ← prototype chạy offline (mở index.html)
    └── billing-result-board-single-file.html  ← cùng prototype, gói 1 file
```

## Cách xem prototype

Mở `prototype/index.html` bằng trình duyệt (hoặc bản online: https://arts.builderos.space/d/01e20ee08f6a5c37bf9e428a45415a6c7ed36cc0bfa77de2c1421bf30558bb35/billing-result-board.html).

- **Screen preview:** chỉnh từng điều kiện (trạng thái thanh toán, segment, hạng tin, điều kiện widget, nhánh A/B JOB, địa điểm tin, gói giảm giá, số voucher, trạng thái API: tải / lỗi…) ở panel phải; panel "Sự kiện ECS" cho thấy event bắn theo thao tác.
- **Interaction:** 7 kịch bản bấm ▶ để tự chạy.
- **Bảng biến thể:** mọi biến thể theo PRD, mỗi ô ghi frame Figma tương ứng hoặc "Chỉ có trong PRD".

Các màn có sẵn ngoài phạm vi (Checkout, Chi tiết đơn hàng, My Rewards, Nâng hạng tin, Edit Ad…) hiện dạng trang tạm ghi đường dẫn đích — không phải design.

## Cách đặt asset

- `upsell-title-icon.png` dùng cho icon tiêu đề upsell (24) và ảnh Gói Tuyển Gấp (40) với crop: phóng 121.87%, lệch trái −9.37%, lệch trên −10.94%.
- `label-image.png` (8×8): hướng lên cho Phổ biến / Đề xuất; lật dọc cho Giảm giá.
- `zigzag-row.svg` (375×19): đặt dưới dải trắng cao 19, chồng −6; kéo giãn theo chiều ngang trên màn rộng hơn 375.
- `widget-pin-card.svg`: Figma có backdrop blur 6 phía sau thẻ — áp dụng nếu platform hỗ trợ.
- `pty-drawer-day-tin.gif`: GIF động khoảng 5 giây, frame đầu trống — khi giảm chuyển động dùng frame giữa.
