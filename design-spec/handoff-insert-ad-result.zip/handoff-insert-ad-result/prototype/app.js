/* Billing Result variant board — modes, device switch, board data, preview panel, interaction scenarios, ECS log.
   Logic: PRD IDEA-9c2e (ct-product-planning …/unified-insert-ad-result-screen/product/product-spec.md, 2026-09-25).
   Visuals: Figma 8470:8135. Every view renders through screen() in index.html. */

/* ═══ Variant board data — grouped by PRD rule; each cell names its closest Figma frame ═══ */
const P = (vertical, status, extra={}) => Object.assign({ vertical, status }, statusDefaults(Object.assign({ status }, extra)), extra);
const FIG = {   /* [mobile, desktop] frame per role */
  pty:{ free_voucher:['8532:31007','8470:9353'], free_subscription:['8532:30869','8470:8991'], paid_fee:['8532:30915','8470:9028'], payment_fail:['8532:30838','8470:9065'], sheet:['8532:31063','8470:9387'], qlt:['8532:31090',null],
        voucher:['8532:31311','8644:39694'], xpost:['8532:31101','8470:9416'], competitor:['8532:31189','8470:9440'], fb_video:['8532:31399','8644:39924'], fb_verify:['8532:31443','8644:40094'],
        pro_voucher:['8532:31355','8644:40554'], pro_xpost:['8532:31145','8644:40190'], pro_competitor:['8532:31250','8644:40361'], pro_video:['8532:31487','8644:40741'] },
  job:{ free_voucher:['8470:9597','8470:10365'], free_subscription:['8470:9503','8470:10212'], paid_fee:['8470:9550','8470:10244'], payment_fail:['8470:9472','8470:10283'], sheet:['8470:9654','8470:10400'], qlt:['8470:9940',null],
        new_promo:['8470:9946','8470:10466'], general_promo:['8470:9992','8470:10539'], new_no_promo:['8470:10039','8470:10503'], general_no_promo:['8470:10085','8644:41774'] }
};
const fig = (v, role, desktop) => (FIG[v][role] || [])[desktop ? 1 : 0] || null;
let cellSeq = 0;
const cell = c => Object.assign({ id:'c' + (++cellSeq) }, c);

function billingCells(v, desktop){
  const base = { label: v === 'job' ? 'recommend' : 'popular' };
  const freeBase = { label: v === 'job' ? 'discount' : 'popular' };
  const cells = [
    cell({ label:'Free - Voucher', rule:'§5.1 · free_listing_fee_voucher', figma:fig(v,'free_voucher',desktop), props:P(v,'free_voucher', freeBase) }),
    cell({ label:'Free - Subs', rule:'§5.1 · subscription_quota', figma:fig(v,'free_subscription',desktop), props:P(v,'free_subscription', freeBase) }),
    cell({ label:'Free - Entitlement', rule:'§5.1 · free_listing_fee_entitlement — dùng lại design Free - Voucher', figma:null, props:P(v,'free_entitlement', freeBase) }),
    cell({ label:'Paid · cổng ngoài — có Xuất hoá đơn', rule:'§5.1 · chưa yêu cầu hoá đơn ở Checkout', figma:fig(v,'paid_fee',desktop), props:P(v,'paid_fee', Object.assign({ payMethod:'momo' }, base)) }),
    cell({ label:'Paid · Đồng Tốt — ẩn Xuất hoá đơn', rule:'AC-09 · ví nội bộ (cũng ẩn khi đã yêu cầu hoá đơn)', figma:null, props:P(v,'paid_fee', Object.assign({ payMethod:'dongtot' }, base)) }),
    cell({ label:'Fail - Listing Fee', rule:'AC-02 · “Thử lại” → Checkout Repayment', figma:fig(v,'payment_fail',desktop), props:P(v,'payment_fail') }),
    cell({ label:'Đang tải — skeleton', rule:'Chờ API: billing hiện ngay, upsell + widget skeleton DS (designer chốt) · Figma chưa có frame', figma:null, props:P(v,'paid_fee', Object.assign({ apiState:'loading' }, base)) }),
    cell({ label:'Lỗi gọi API — empty state', rule:'API upsell / widget lỗi → 1 empty state thay 2 khối · wording theo vertical', figma: v === 'pty' && !desktop ? '8903:24626' : null, props:P(v,'paid_fee', Object.assign({ apiState:'error' }, base)) }),
    cell({ label: desktop ? 'Chọn số ngày · dialog' : 'Chọn số ngày · bottomsheet', rule:'AC-16 · chọn số ngày → Checkout', figma:fig(v,'sheet',desktop), props:P(v,'paid_fee', Object.assign({ overlay:'sheet', static:true }, base)), frameH: desktop ? null : 885 }),
    cell({ label:'Chọn số ngày · tin sắp hết hạn', rule:'AC-16 · ẩn gói dài hơn thời hạn còn lại', figma:null, props:P(v,'paid_fee', Object.assign({ overlay:'sheet', static:true, lifetime:'short' }, base)), frameH: desktop ? null : 885 })
  ];
  if (!desktop) cells.push(cell({ label:'× → Quản lý tin', rule:'AC-17 · User Ad Dashboard', figma:fig(v,'qlt',false), image: v === 'pty' ? 'qltPty' : 'qltJob' }));
  return cells;
}
const PTY_CONDS = [['voucher','Có voucher PTY (free-listing)'],['xpost','Có tin Cross-Post'],['competitor','Có tin competitor, chưa Cross-Post'],['fb_video','Fallback · tin chưa có video'],['fb_verify','Fallback · Phòng trọ chưa đăng ký Phòng 5 tốt'],['fb_empty','Fallback · không card nào hợp lệ']];
function ptySegmentCells(segment, desktop){
  const tier = segment === 'new' ? 'casual' : 'professional';
  return PTY_CONDS.map(([cond, title]) => {
    const fb = cond.startsWith('fb_');
    const order = !fb && segment === 'new' ? 'Widget → Upsell' : 'Upsell → Widget';
    const role = tier === 'professional' ? { voucher:'pro_voucher', xpost:'pro_xpost', competitor:'pro_competitor', fb_video:'pro_video', fb_verify:'fb_verify' }[cond] : cond;
    return cell({ label:title, rule:`AC-15 · ${order} · ${PTY_TIER_NAME[tier]}${cond === 'voucher' ? ' · 1 voucher' : ''}`, figma: role ? fig('pty', role, desktop) : null,
      diff: !fb && segment === 'new' && role ? 'Figma đặt Upsell trước — board theo PRD AC-15' : null,
      props:P('pty','paid_fee',{ ptySegment:segment, ptyTier:tier, ptyCond:cond, voucherCount: cond === 'voucher' ? '1' : '3', label:'popular' }) });
  });
}
function ptyTierCells(){
  return ['casual','professional','elite'].map(t => cell({ label:`${PTY_TIER_NAME[t]} (${t[0].toUpperCase() + t.slice(1)})`,
    rule: t === 'casual' ? '§5.2 · chạm Tin ưu tiên → luồng nâng hạng, không mở bottomsheet' : t === 'professional' ? '§5.5 · Tin ưu tiên → Bump 3/7' : '§5.5 · Bump 3/7 → Tin ưu tiên',
    figma:null, section:{ vertical:'pty', kind:'upsell', props:{ ptyTier:t, ptySegment:'retain' } } }));
}
function jobBucketCells(bucket, desktop){
  const mk = (promo, title, role) => cell({ label:title,
    rule: bucket === 'new' ? (promo === 'none' ? 'AC-14 · (2) VLT → (3) Bí kíp' : 'AC-14 · (1) Promotion → (2) VLT') : (promo === 'none' ? 'AC-14 · (1) VLT → (3) Bí kíp' : 'AC-14 · (1) VLT → (2) Promotion'),
    figma: role ? fig('job', role, desktop) : null, diff: bucket === 'general' && role && promo !== 'none' ? 'Figma đặt voucher trên upsell — PM chọn theo PRD (Open Risk 50)' : null,
    props:P('job','paid_fee',{ jobBucket:bucket, jobPromo:promo, voucherCount:'3', label: bucket === 'new' && promo !== 'none' ? 'recommend' : 'popular' }) });
  return bucket === 'new'
    ? [mk('free_listing','Có voucher đăng tin miễn phí → card đơn', null), mk('other_voucher','Chỉ voucher khác → danh sách (≤3)','new_promo'), mk('none','Không có promotion','new_no_promo')]
    : [mk('free_listing','Có voucher đăng tin miễn phí → card đơn','general_promo'), mk('other_voucher','Chỉ voucher khác → danh sách (≤3)', null), mk('none','Không có promotion','general_no_promo')];
}
function jobTierCells(){
  const t = { fee:'Phí đăng tin — 3 gói', t3:'Tier 3 — Tuyển Gấp + Tối Ưu', t2:'Tier 2 — Tuyển Gấp', t1:'Tier 1 — ẩn upsell' };
  return Object.keys(t).map(k => cell({ label:t[k], rule:'§5.2 · chỉ áp dụng Paid Fee; Free luôn 3 gói', figma:null,
    section:{ vertical:'job', kind:'upsell', props:{ jobTier:k, status:'paid_fee', label:'recommend' } } }));
}
function multiVoucherCells(desktop){
  const mob = desktop ? 1 : 0;
  const job = (promo, n, label, rule, figma, diff) => cell({ label, rule, figma, diff,
    props:P('job','paid_fee',{ jobBucket:'new', jobPromo:promo, voucherCount:String(n), label:'recommend' }) });
  return [
    cell({ label:'PTY · có voucher (đăng tin miễn phí)', rule:'AC-15 · PTY luôn card đơn, bất kể số voucher', figma:['8532:31311','8644:39694'][mob], diff:'Figma có frame danh sách voucher PTY (8644:39183) — PRD không dùng',
      props:P('pty','paid_fee',{ ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', label:'popular' }) }),
    job('free_listing', 3, 'JOB · có voucher đăng tin miễn phí (+ voucher khác)', '§5.6 · card đơn — voucher đăng tin miễn phí mới nhất', ['8470:9992','8470:10539'][mob]),
    job('other_voucher', 1, 'JOB · 1 voucher khác', '§5.6 · danh sách 1 dòng', ['8644:38448','8644:41653'][mob]),
    job('other_voucher', 2, 'JOB · 2 voucher khác', '§5.6 · danh sách 2 dòng', null),
    job('other_voucher', 3, 'JOB · 3 voucher khác', '§5.6 · danh sách 3 voucher mới nhất', ['8649:41976','8644:41517'][mob]),
    job('other_voucher', 5, 'JOB · 5 voucher khác', '§5.6 · 3 voucher mới nhất + “Xem tất cả” (design thêm)', null)
  ];
}
function componentCells(){
  return [
    cell({ label:'Voucher card · HSD bình thường', rule:'§5.6', figma:'8470:8929', section:{ vertical:'pty', kind:'widget', props:{ ptyCond:'voucher', expiry:'normal' } } }),
    cell({ label:'Voucher card · còn ≤3 ngày', rule:'§5.6 · đỏ “Còn N ngày”', figma:null, section:{ vertical:'pty', kind:'widget', props:{ ptyCond:'voucher', expiry:'soon' } } }),
    cell({ label:'Voucher list · còn ≤3 ngày', rule:'§5.6', figma:'8649:41976', section:{ vertical:'job', kind:'voucher_list', props:{ expiry:'soon' } } }),
    cell({ label:'upsell-section · Label', rule:'Phổ biến / Giảm giá / không nhãn', figma:'8470:8855', section:{ vertical:'job', kind:'labels' } })
  ];
}
function boardFor(desktop){
  cellSeq = desktop ? 500 : 0;
  const D = desktop ? 'Desktop' : 'Mobile';
  const groups = [
    { id:`${D}-pty-billing`, title:`${D} · PTY · Trạng thái thanh toán`, note:'§5.1 — 4 success state (thêm Free-Entitlement), Fail, “Xuất hoá đơn” theo phương thức thanh toán, bottomsheet chọn số ngày.', cells:billingCells('pty', desktop) },
    { id:`${D}-pty-new`, title:`${D} · PTY · Segment New`, note:'PRD AC-15: Widget trước, Upsell sau (fallback: Upsell trước). Copy theo New. Hạng tin mẫu: Casual (Bump → Tin ưu tiên).', cells:ptySegmentCells('new', desktop) },
    { id:`${D}-pty-retain`, title:`${D} · PTY · Segment Retain`, note:'PRD AC-15: Upsell trước, Widget sau. Copy theo Retain. Hạng tin mẫu: Professional (Tin ưu tiên → Bump).', cells:ptySegmentCells('retain', desktop) },
    { id:`${D}-job-billing`, title:`${D} · JOB · Trạng thái thanh toán`, note:'§5.1 — giống PTY.', cells:billingCells('job', desktop) },
    { id:`${D}-job-new`, title:`${D} · JOB · New Listors`, note:'AC-14 — UCDP ucdp_job_newusers_allgrowthsources. (1) Promotion → (2) VLT display-boost → (3) Bí kíp; luôn đúng 1 widget.', cells:jobBucketCells('new', desktop) },
    { id:`${D}-job-general`, title:`${D} · JOB · General Listors`, note:'AC-14 — (1) VLT display-boost + copy tính cạnh tranh → (2) Promotion → (3) Bí kíp.', cells:jobBucketCells('general', desktop) },
    { id:`${D}-multi-voucher`, title:`${D} · Nhiều voucher`, note:'PRD §5.6: có voucher đăng tin miễn phí → card đơn (PTY luôn card đơn) · chỉ có voucher khác → danh sách “Gợi ý cho bạn” tối đa 3 voucher mới nhất (+ “Xem tất cả” khi > 3). Chạm “Sử dụng” → Ưu đãi của tôi. Dòng 2–4 là dữ liệu mẫu.', cells:multiVoucherCells(desktop) }
  ];
  if (!desktop){
    groups.splice(3, 0, { id:'Mobile-pty-tier', title:'Mobile · PTY · Hạng tin hiện tại', note:'§5.2 — Casual khoá Tin ưu tiên (chạm → nâng hạng); thứ tự gói theo hạng.', cells:ptyTierCells() });
    groups.push({ id:'Mobile-job-tier', title:'Mobile · JOB · Gói theo hạng tin (Paid Fee)', note:'§5.2 / AC-04 / AC-EC-08.', cells:jobTierCells() });
    groups.push({ id:'Mobile-components', title:'Component & Element', note:'Biến thể component dùng chung.', cells:componentCells() });
  }
  return groups;
}
const PRD_DIFFS = [
  'PTY thứ tự khối theo PRD AC-15 (designer chốt): Segment New → widget <b>trước</b> Upsell; Retain và fallback → Upsell trước. Các frame Figma đều đặt Upsell trước — cần cập nhật Figma.',
  'Copy Tin ưu tiên (New): PRD “Tin được ghim và nổi bật ở TOP 5 vị trí đầu tiên của trang tìm kiếm.” — Figma đang dùng câu của Retain.',
  'JOB General Listors có promotion: PRD đặt upsell (VLT) trước voucher (Open Risk 50) — Figma general_listor_promo đặt voucher trước.',
  'Widget luôn đúng 1 usecase (AC-14/15) — frame Billing mobile trong Figma hiện 3 widget cùng lúc.',
  'Chưa có frame: Free-Entitlement, ẩn “Xuất hoá đơn”, JOB tier 1–3, Casual khoá Tin ưu tiên, bottomsheet ẩn gói dài hơn thời hạn tin, fallback trống, voucher “Còn N ngày” dạng card đơn.',
  '“Thử lại” mở Checkout Repayment (AC-10) — không tự thanh toán lại.',
  'Desktop “Quản lý tin →” = Dismiss (AC-17). Pro = Professional = “Tin Tăng Cường” (desktop Figma ghi “Tin nâng cao”).',
  'Voucher theo PRD §5.6 / AC-15: có voucher đăng tin miễn phí → card đơn, PTY luôn card đơn; danh sách chỉ cho JOB khi chỉ có voucher khác, tiêu đề “Gợi ý cho bạn”. Figma (8644:39183, “Ưu đãi cho bạn” / “Ưu đãi”) cần cập nhật.',
  'Copy tính cạnh tranh theo PRD §5.5: “Tin của bạn đang cạnh tranh với {n} Nhà Tuyển dụng khác” trên gói nổi bật — phần đầu câu chưa có trong PRD (PRD ghi “…”). Figma đặt dòng khác dưới tiêu đề — cần cập nhật.',
  '“Xem tất cả” (> 3 voucher): design thêm, chưa có trong PRD và Figma.'
];

/* ═══ State ═════════════════════════════════════════════════════════════════ */
const LS_KEY = 'billingBoard.v2';
let mode = 'screen', device = 'mobile';
let state = Object.assign({}, DEFAULTS);
let ixSel = 'svc', ixVertical = 'pty';
let presetSel = null;
function save(){ try { localStorage.setItem(LS_KEY, JSON.stringify({ mode, device, state, ixSel, ixVertical, presetSel })); } catch(e){} }
function load(){ try { const s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); if (s){ mode = s.mode || mode; device = s.device || device; state = Object.assign({}, DEFAULTS, s.state, { overlay:'none', static:false }); ixSel = s.ixSel || ixSel; ixVertical = s.ixVertical || ixVertical; presetSel = s.presetSel || null; } } catch(e){} }

const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const headH = () => $('#head').offsetHeight;

/* ═══ ECS event log (PRD §7.2) ══════════════════════════════════════════════ */
function ecs(st, name, fields){
  if (!st) return;
  const p = st._props;
  const row = Object.assign({ ad_id:123141241, category_id:VERT[p.vertical].category, listing_tier: p.vertical === 'pty' ? p.ptyTier : p.jobTier }, fields);
  st._ecs = (st._ecs || []).concat([{ name, row }]).slice(-30);
  renderEcs(st);
}
function renderEcs(st){
  const host = st.closest('#ix-stage') ? $('#ix-panel [data-ecs]') : $('#pg-panel [data-ecs]');
  if (!host) return;
  const list = (st._ecs || []).slice().reverse();
  host.innerHTML = list.length ? list.map(e => `<li><b>${e.name}</b><span>${Object.entries(e.row).map(([k,v]) => `${k}=${esc(v)}`).join(' · ')}</span></li>`).join('') : '<li class="empty">Chưa có sự kiện</li>';
}
function ecsOnMount(st){
  const p = st._props; if (p.status === 'payment_fail') return;
  if ($('[data-sec="upsell"]', st)) ecs(st, 'insert_ad_result_upsell_view', { event_category:'upsell_block', event_action:'view', page_type:`${p.vertical}_insert_ad_result` });
  const uc = widgetUsecase(p);
  if (uc && $('[data-sec="suggestion"], [data-sec="voucher_list"]', st)) ecs(st, 'insert_ad_result_widget_view', { usecase:uc, bucket: p.vertical === 'pty' ? p.ptySegment : p.jobBucket });
}

/* ═══ Stage builders (shared by Screen preview + Interaction) ═══════════════ */
function stageHTML(props){
  const o = Object.assign({}, DEFAULTS, props, { overlay:'none' });
  const dest = `<div class="dest" data-dest><div class="dest-head"><button data-act="dest-back" aria-label="Quay lại">‹</button><span data-dest-title></span></div><div class="dest-body" data-dest-body></div></div>`;
  if (device === 'desktop'){
    return `<div class="dpage-wrap" data-stage>
      ${screen(Object.assign({}, o, { desktop:true }))}
      <div class="d-ovl" data-ovl><div class="scrim" data-act="sheet-close"></div><div class="d-center"><div class="dialog" role="dialog" aria-modal="true"></div></div></div>
      ${dest}
    </div>`;
  }
  return `<div class="phone" data-stage><div class="phone-screen">
    <div class="phone-scroll">${screen(o)}</div>
    <div class="ovl" data-ovl><div class="scrim" data-act="sheet-close"></div><div class="sheet" role="dialog" aria-modal="true"></div></div>
    <div class="qlt" data-qlt><button class="icon-btn qlt-back" data-act="qlt-back" aria-label="Quay lại" style="position:absolute;left:0;top:44px;width:56px;height:52px"></button>${img(o.vertical === 'job' ? 'qltJob' : 'qltPty')}</div>
    ${dest}
    <div class="toast" data-toast></div>
    <div class="phone-home"></div>
  </div></div>`;
}
function mountStage(host, props){
  host.innerHTML = stageHTML(props);
  const st = $('[data-stage]', host);
  st._props = Object.assign({}, DEFAULTS, props); st._ecs = [];
  const sc = $('.phone-scroll', st);
  if (sc) sc.addEventListener('scroll', () => sc.classList.toggle('scrolled', sc.scrollTop > 2), { passive:true });
  fitPages(); renderEcs(st); ecsOnMount(st);
  return st;
}

/* ═══ Demo behaviour (event delegation; Interaction scenarios use the same handlers) ═══ */
const overlayStack = [];
const popStack = el => { const i = overlayStack.indexOf(el); if (i > -1) overlayStack.splice(i, 1); };
/* existing screens outside this spec — a labelled stub, never a fake build of them */
function openDest(st, title, route, note){
  const d = $('[data-dest]', st);
  $('[data-dest-title]', d).textContent = title;
  $('[data-dest-body]', d).innerHTML = `<p>Màn có sẵn — ngoài phạm vi spec này.</p>${route ? `<code>${esc(route)}</code>` : ''}${note ? `<p>${note}</p>` : ''}`;
  d.classList.add('open'); overlayStack.push(d); emit(st, 'dest-open');
}
function closeDest(d){ d.classList.remove('open'); popStack(d); emit(d.closest('[data-stage]'), 'dest-close'); }
function toggleCard(cardInfo){
  const card = cardInfo.closest('.card'); const open = !card.classList.contains('open');
  card.classList.toggle('open', open);
  cardInfo.setAttribute('aria-expanded', String(open));
  $('.card-chev', card).src = A[open ? 'chevronUp' : 'chevronDown'];
  card.dataset.dsVariant = `Collapse=${open ? 'No' : 'Yes'}`;
  const st = cardInfo.closest('[data-stage]');
  if (st){ st._props.card = open ? 'expanded' : 'collapsed'; if (st.closest('#pg-stage')){ state.card = st._props.card; save(); syncPanelButtons(); } }
  emit(st, open ? 'card-open' : 'card-close');
  fitPages();
}
function openSheet(btn){
  const st = btn.closest('[data-stage]'); const ovl = $('[data-ovl]', st);
  const panel = $('.sheet, .dialog', ovl);
  const vertical = btn.dataset.vertical || st._props.vertical;
  const cfg = sheetCfg(vertical, st._props.lifetime);
  const sel = Math.min(SHEETS[vertical].sel, cfg.durs.length - 1);
  panel.innerHTML = sheetContent(vertical, btn.dataset.name, btn.dataset.svc, sel, device === 'desktop', st._props.lifetime);
  Object.assign(panel.dataset, { vertical, sel, svc:btn.dataset.svc });
  if (device === 'desktop') st.style.setProperty('--head-h', headH() + 'px');
  ovl.classList.add('open'); overlayStack.push(ovl);
  const pkg = ECS_PKG[btn.dataset.svc];
  ecs(st, 'insert_ad_result_upsell_click', { event_category:'upsell_block', event_action:'click', event_label:pkg });
  ecs(st, 'insert_ad_result_bottomsheet_show', { event_category:'bottomsheet', event_action:'show', event_label:pkg });
  emit(st, 'sheet-open');
}
function closeSheet(ovl, viaPay){
  const st = ovl.closest('[data-stage]'); const panel = $('.sheet, .dialog', ovl);
  if (!viaPay && ovl.classList.contains('open') && panel.dataset.svc) ecs(st, 'insert_ad_result_bottomsheet_close', { event_category:'bottomsheet', event_action:'close', event_label:ECS_PKG[panel.dataset.svc] });
  ovl.classList.remove('open'); popStack(ovl);
  if (!viaPay) emit(st, 'sheet-close');
}
function pickDuration(btn){
  const panel = btn.closest('.sheet, .dialog'); const i = +btn.dataset.i; const st = btn.closest('[data-stage]');
  const cfg = sheetCfg(panel.dataset.vertical, st._props.lifetime);
  panel.dataset.sel = i;
  $$('.dur', panel).forEach((b, j) => { b.classList.toggle('sel', j === i); b.setAttribute('aria-pressed', String(j === i)); });
  $('[data-tot]', panel).innerHTML = sheetTotal(cfg, i);
  ecs(st, 'insert_ad_result_bottomsheet_click', { event_category:'bottomsheet', event_action:'click', event_label:ECS_PKG[panel.dataset.svc], duration:parseInt(cfg.durs[i].d, 10) });
  emit(st, 'dur');
}
function pay(btn){
  const st = btn.closest('[data-stage]'); const ovl = btn.closest('[data-ovl]'); const panel = btn.closest('.sheet, .dialog');
  const d = sheetCfg(panel.dataset.vertical, st._props.lifetime).durs[+panel.dataset.sel];
  ecs(st, 'insert_ad_result_upsell_confirm', { event_category:'upsell_block', event_action:'confirm', event_label:ECS_PKG[panel.dataset.svc], duration:parseInt(d.d, 10) });
  emit(st, 'pay');
  closeSheet(ovl, true);
  openDest(st, 'Checkout', `checkout · ${ECS_PKG[panel.dataset.svc]} · ${d.d} · ${money(d.p)}`, 'Thanh toán xong → Billing Result, không quay lại màn này (AC-EC-06).');
}
function retry(btn){
  const st = btn.closest('[data-stage]');
  ecs(st, 'insert_ad_result_action_click', { event_category:'action_button', event_action:'click', event_label:'retry|-|checkout_repayment' });
  emit(st, 'retry');
  openDest(st, 'Checkout Repayment', 'checkout repayment · order 123141241', 'Không tự thanh toán lại — người dùng thanh toán lại đúng đơn hàng này (AC-10).');
}
function dismiss(st){
  ecs(st, 'insert_ad_result_dismiss', { event_category:'header', event_action:'close', destination:'user_ad_dashboard' });
  const q = $('[data-qlt]', st);
  if (q){ q.classList.add('open'); overlayStack.push(q); emit(st, 'qlt-open'); }
  else openDest(st, 'Quản lý tin (User Ad Dashboard)', 'user_ad_dashboard', 'Figma chưa có màn desktop — AC-17.');
}
function closeQlt(q){ q.classList.remove('open'); popStack(q); emit(q.closest('[data-stage]'), 'qlt-close'); }
const WIDGET_DEST = {   /* PRD §5.6 */
  voucher:(p, btn) => (btn && btn.dataset.act === 'voucher' ? btn.dataset.free : (p.vertical === 'pty' || p.jobPromo === 'free_listing')) ? ['Đăng tin (Insert Ad)','insert_ad'] : ['Ưu đãi của tôi (My Rewards)','my_rewards'],
  xpost:() => ['Đăng tin (ready-to-post PTY)','chotot-app://www.chotot.com/dang-tin-v3/ready-to-post-pty'],
  competitor:() => ['Đăng tin (Insert Ad)','insert_ad'],
  video:() => ['Sửa tin (Edit Ad)','edit_ad/123141241'],
  verify:() => ['Sửa tin (Edit Ad)','edit_ad/123141241'],
  bikip:() => ['Bí kíp tuyển dụng','chuongtrinh.vieclamtot.com/tin-dang-chat-luong']
};
function widgetTap(btn){
  const st = btn.closest('[data-stage]'); const p = st._props;
  const kind = btn.dataset.widget || 'voucher';
  const [title, route] = WIDGET_DEST[kind](p, btn);
  ecs(st, 'insert_ad_result_widget_click', { usecase:widgetUsecase(p), bucket: p.vertical === 'pty' ? p.ptySegment : p.jobBucket, destination:route });
  emit(st, 'widget');
  openDest(st, title, route, kind === 'video' || kind === 'verify' ? 'Deep link tới Edit Ad của tin cụ thể là phạm vi mới (Open Risk 46).' : '');
}
function onDemoClick(e){
  const t = e.target.closest('[data-act]'); if (!t) return;
  const st = t.closest('[data-stage]'); if (!st) return;
  const act = t.dataset.act;
  if (act === 'card') toggleCard(t);
  else if (act === 'svc') openSheet(t);
  else if (act === 'upgrade'){ ecs(st, 'insert_ad_result_upsell_click', { event_category:'upsell_block', event_action:'click', event_label:'sticky_ad' }); emit(st, 'upgrade'); openDest(st, 'Nâng hạng tin', 'listing-tier upgrade (Casual → Professional / Elite)', 'Hạng Casual không mua trực tiếp Tin ưu tiên — chuyển thẳng tới luồng nâng hạng có sẵn, không có UI nhắc trung gian (AC-EC-07).'); }
  else if (act === 'sheet-close') closeSheet(t.closest('[data-ovl]'));
  else if (act === 'dur') pickDuration(t);
  else if (act === 'pay') pay(t);
  else if (act === 'retry') retry(t);
  else if (act === 'close' || act === 'manage') dismiss(st);
  else if (act === 'qlt-back') closeQlt(t.closest('[data-qlt]'));
  else if (act === 'dest-back') closeDest(t.closest('[data-dest]'));
  else if (act === 'sell-faster') openDest(st, t.textContent.trim(), st._props.vertical === 'pty' ? 'POS Premium Feature — Bán nhanh hơn (PTY)' : 'JOB Premium Features — Tuyển nhanh hơn', 'Đích CTA của empty state chưa chốt trong PRD — cần PM xác nhận.');
  else if (act === 'order') openDest(st, 'Chi tiết đơn hàng', 'order detail · 123141241');
  else if (act === 'see-all'){ ecs(st, 'insert_ad_result_widget_click', { usecase:'voucher', bucket: st._props.vertical === 'pty' ? st._props.ptySegment : st._props.jobBucket, destination:'my_rewards' }); openDest(st, 'Ưu đãi của tôi (My Rewards)', 'my_rewards', 'Từ link “Xem tất cả” khi có hơn 3 voucher.'); }
  else if (act === 'invoice') openDest(st, 'Xuất hoá đơn', 'invoice request · order 123141241');
  else if (act === 'widget' || act === 'voucher') widgetTap(t);
}
document.addEventListener('click', e => { if (e.target.closest('#pg-stage, #ix-stage')) onDemoClick(e); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && overlayStack.length){
    const top = overlayStack[overlayStack.length - 1];
    if (top.matches('[data-qlt]')) closeQlt(top); else if (top.matches('[data-dest]')) closeDest(top); else closeSheet(top);
  }
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.card-info') && e.target.closest('[data-stage]')){ e.preventDefault(); toggleCard(e.target); }
});
function emit(st, ev){ if (st && st._listen) st._listen(ev); }

/* ═══ Screen preview ════════════════════════════════════════════════════════ */
const CONTROLS = [
  ['vertical','Ngành hàng',[['pty','Nhà Tốt (PTY)'],['job','Việc Làm Tốt (JOB)']]],
  ['status','Kết quả (§5.1)',[['free_voucher','Free · Voucher'],['free_subscription','Free · Gói'],['free_entitlement','Free · Entitlement'],['paid_fee','Có phí · Thành công'],['payment_fail','Thất bại']]],
  ['payMethod','Phương thức thanh toán (AC-09)',[['momo','Cổng ngoài · chưa YC hoá đơn'],['momo_invoiced','Cổng ngoài · đã YC hoá đơn'],['dongtot','Đồng Tốt']], { status:'paid_fee' }],
  ['card','Thẻ tin đăng',[['collapsed','Thu gọn'],['expanded','Mở rộng']]],
  ['ptySegment','Segment (UCDP return_seller)',[['new','New'],['retain','Retain']], { vertical:'pty' }],
  ['ptyOrder','Thứ tự khối PTY',[['prd','PRD AC-15 (mặc định)'],['figma','Figma cũ · Upsell luôn trước']], { vertical:'pty' }],
  ['ptyTier','Hạng tin hiện tại (§5.2)',[['casual','Casual · Tin cơ bản'],['professional','Professional · Tin Tăng Cường'],['elite','Elite · Tin Nâng Cao']], { vertical:'pty' }],
  ['ptyCond','Điều kiện widget (ưu tiên trái → phải)',[['voucher','Có voucher'],['xpost','Có Cross-Post'],['competitor','Có competitor'],['fb_video','Fallback · video'],['fb_verify','Fallback · xác thực'],['fb_empty','Fallback · trống']], { vertical:'pty' }],
  ['jobBucket','Nhóm (UCDP newusers_allgrowthsources)',[['new','New Listors'],['general','General Listors']], { vertical:'job' }],
  ['jobPromo','Promotion',[['free_listing','Voucher đăng tin miễn phí'],['other_voucher','Voucher khác'],['none','Không có']], { vertical:'job' }],
  ['jobTier','Hạng tin hiện tại (chỉ Paid Fee)',[['fee','Phí đăng tin'],['t3','Tier 3'],['t2','Tier 2'],['t1','Tier 1']], { vertical:'job', status:'paid_fee' }],
  ['voucherCount','Số voucher khác (danh sách, §5.6)',[['1','1'],['2','2'],['3','3'],['5','Nhiều hơn 3 (5)']], { voucher:true }],
  ['apiState','Dữ liệu upsell / widget',[['ok','Có dữ liệu'],['loading','Đang tải → skeleton'],['error','Lỗi gọi API → empty state']]],
  ['expiry','Hạn ưu đãi',[['normal','HSD bình thường'],['soon','Còn ≤3 ngày']]],
  ['lifetime','Thời hạn tin còn lại (bottomsheet)',[['full','Đủ dài'],['short','Sắp hết hạn']]],
  ['label','Nhãn gói nổi bật',[['popular','Phổ biến'],['discount','Giảm giá'],['recommend','Đề xuất'],['none','Không nhãn']]]
];
function renderPreview(){ mountStage($('#pg-stage'), state); }
const hasVoucher = s => s.vertical === 'job' && s.jobPromo === 'other_voucher';   /* số voucher chỉ đổi giao diện khi là danh sách */
const controlVisible = only => !only || ((!only.vertical || only.vertical === state.vertical) && (!only.status || only.status === state.status) && (!only.voucher || hasVoucher(state)));
function renderPanel(){
  const p = $('#pg-panel'); const fail = state.status === 'payment_fail';
  const ctl = CONTROLS.map(([key, label, opts, only]) => {
    if (!controlVisible(only)) return '';
    const off = fail && !['vertical','status','card'].includes(key);
    return `<div class="ctl${off?' off':''}"><label>${label}${off?' — ẩn khi thất bại':''}</label><div class="seg" role="group">${opts.map(([v,t]) =>
      `<button data-key="${key}" data-val="${v}" aria-pressed="${String(state[key] === v)}">${t}</button>`).join('')}</div></div>`;
  }).join('');
  const cells = boardFor(device === 'desktop').flatMap(g => g.cells.filter(c => c.props && c.props.vertical === state.vertical && !c.props.overlay));
  p.innerHTML = `<h2>Biến thể màn hình</h2><p class="note">Logic theo PRD IDEA-9c2e (25/09), giao diện theo Figma. Bấm thẻ tin, “${VERT[state.vertical].cta}”, widget, ${device==='desktop'?'“Quản lý tin →”':'✕'} hoặc “Thử lại” ngay trên màn.</p>
    ${ctl}<div class="hr"></div>
    <div class="ctl"><label>Preset (${VERT[state.vertical].name} · ${device === 'desktop' ? 'Desktop' : 'Mobile'})</label>
      <div class="chips">${cells.map(c => `<button class="chip${presetSel === c.id ? ' on' : ''}" data-preset="${c.id}" title="${esc(c.rule || '')}">${esc(c.label)}</button>`).join('')}</div></div>
    <div class="ix-actions"><button data-reset>Đặt lại</button></div>
    <div class="hr"></div><h2>Sự kiện ECS</h2><p class="note">insert_ad_result_* (PRD §7.2), bắn theo thao tác trên màn.</p><ul class="ecs" data-ecs></ul>`;
  const st = $('#pg-stage [data-stage]'); if (st) renderEcs(st);
}
function syncPanelButtons(){ $$('#pg-panel [data-key]').forEach(b => b.setAttribute('aria-pressed', String(state[b.dataset.key] === b.dataset.val))); }
document.addEventListener('click', e => {
  const b = e.target.closest('#pg-panel button'); if (!b) return;
  if (b.dataset.key){
    const k = b.dataset.key; state[k] = b.dataset.val;
    if (k === 'vertical') state.label = state.vertical === 'job' ? 'recommend' : 'popular';
    if (k === 'status' || k === 'payMethod') Object.assign(state, statusDefaults(state));
    presetSel = null;
  } else if (b.dataset.preset){
    const c = boardFor(device === 'desktop').flatMap(g => g.cells).find(x => x.id === b.dataset.preset);
    state = Object.assign({}, DEFAULTS, c.props, { overlay:'none', static:false }); presetSel = c.id;
  } else if (b.hasAttribute('data-reset')){ state = Object.assign({}, DEFAULTS); presetSel = null; }
  else return;
  save(); renderPreview(); renderPanel();
});

/* ═══ Interaction scenarios ═════════════════════════════════════════════════ */
const svcFeed = v => v === 'pty' ? { vertical:v, status:'paid_fee', ptySegment:'retain', ptyTier:'elite', ptyCond:'xpost' } : { vertical:v, status:'paid_fee', jobBucket:'general', jobPromo:'none', label:'recommend' };
const SCENARIOS = [
  { id:'svc', devices:['mobile','desktop'], group:'Upsell', title:'Thêm gói → chọn số ngày → Checkout', desc:'AC-16 · upsell_click → bottomsheet_show / click → upsell_confirm', feed:svcFeed,
    steps:() => [`Chạm “${VERT[ixVertical].cta}” ở gói đầu tiên`, device === 'desktop' ? 'Dialog mở — mặc định gói giữa (-12%)' : 'Bottomsheet mở — mặc định gói giữa (-12%)', 'Chọn số ngày khác', 'Giá + “Tiết kiệm” cập nhật', 'Chạm “Thanh toán” → Checkout có sẵn'],
    setup(st){ ixStep(0); st._listen = ev => { if (ev === 'sheet-open') ixStep(2); if (ev === 'dur') ixStep(4); if (ev === 'pay') ixStep(5, true); }; },
    async play(st){ const b = $('.svc [data-act="svc"]', st); scrollToEl(st, b); await sleep(700); b.click(); await sleep(1200);
      const durs = () => $$('[data-ovl] .dur', st); durs()[durs().length - 1].click(); await sleep(1100); durs()[0].click(); await sleep(1100); $('[data-ovl] [data-act="pay"]', st).click(); } },
  { id:'sheet-close', devices:['mobile','desktop'], group:'Upsell', title:'Đóng bottomsheet, không thanh toán', desc:'AC-EC-05 · bottomsheet_close', feed:svcFeed,
    steps:() => [`Chạm “${VERT[ixVertical].cta}”`, 'Bottomsheet mở', 'Chạm ✕ hoặc vùng tối để đóng', 'Màn giữ nguyên, không tạo đơn'],
    setup(st){ ixStep(0); st._listen = ev => { if (ev === 'sheet-open') ixStep(2); if (ev === 'sheet-close') ixStep(4, true); }; },
    async play(st){ const b = $('.svc [data-act="svc"]', st); scrollToEl(st, b); await sleep(700); b.click(); await sleep(1300); $('[data-ovl] .sh-head [data-act="sheet-close"]', st).click(); } },
  { id:'upgrade', devices:['mobile','desktop'], verticals:['pty'], group:'Upsell', title:'Casual chạm Tin ưu tiên → nâng hạng tin', desc:'§5.2 / AC-EC-07',
    feed:v => ({ vertical:v, status:'paid_fee', ptySegment:'retain', ptyTier:'casual', ptyCond:'xpost' }),
    steps:() => ['Hạng tin hiện tại: Casual (Tin cơ bản)','Chạm “Thêm” ở Tin ưu tiên','Chuyển thẳng tới luồng nâng hạng — không mở bottomsheet'],
    setup(st){ ixStep(1); st._listen = ev => { if (ev === 'upgrade') ixStep(3, true); }; },
    async play(st){ const b = $('[data-act="upgrade"]', st); scrollToEl(st, b); await sleep(800); b.click(); } },
  { id:'widget', devices:['mobile','desktop'], group:'Widget', title:'Chạm widget “Gợi ý cho bạn”', desc:'§5.6 · widget_view → widget_click',
    feed:v => v === 'pty' ? { vertical:v, status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'xpost' } : { vertical:v, status:'paid_fee', jobBucket:'new', jobPromo:'none' },
    steps:() => ['Widget hiển thị đúng 1 usecase theo điều kiện','Chạm CTA của widget','Đi tới màn đích theo §5.6'],
    setup(st){ ixStep(1); st._listen = ev => { if (ev === 'widget') ixStep(3, true); }; },
    async play(st){ const b = $('[data-act="widget"], [data-act="voucher"]', st); scrollToEl(st, b); await sleep(800); b.click(); } },
  { id:'card', devices:['mobile','desktop'], group:'Billing', title:'Mở / thu gọn chi tiết đơn hàng', desc:'Card-collapse&expand',
    feed:v => ({ vertical:v, status:'paid_fee', card:'collapsed', label: v === 'job' ? 'recommend' : 'popular' }),
    steps:() => ['Thẻ tin đăng đang thu gọn','Chạm vào thẻ tin đăng','Hiện Mã đơn hàng + Xuất hoá đơn','Chạm lại để thu gọn'],
    setup(st){ let opened = false; ixStep(1); st._listen = ev => { if (ev === 'card-open'){ opened = true; ixStep(3); } if (ev === 'card-close' && opened) ixStep(4, true); }; },
    async play(st){ const c = () => $('.card-info', st); await sleep(700); scrollToEl(st, c()); c().click(); await sleep(1600); c().click(); } },
  { id:'retry', devices:['mobile','desktop'], group:'Billing', title:'Thanh toán thất bại → Thử lại', desc:'AC-10 · Checkout Repayment',
    feed:v => ({ vertical:v, status:'payment_fail', card:'expanded' }),
    steps:() => ['Thanh toán thất bại — chỉ còn tóm tắt đơn + “Thử lại”','Chạm “Thử lại”','Mở Checkout Repayment của đơn hàng (không tự thanh toán lại)'],
    setup(st){ ixStep(1); st._listen = ev => { if (ev === 'retry') ixStep(3, true); }; },
    async play(st){ await sleep(800); $('[data-act="retry"]', st).click(); } },
  { id:'manage', devices:['mobile','desktop'], group:'Điều hướng', title:'Đóng → Quản lý tin', desc:'AC-17 · insert_ad_result_dismiss',
    feed:v => ({ vertical:v, status:'paid_fee', card:'expanded', label: v === 'job' ? 'recommend' : 'popular' }),
    steps:() => [device === 'desktop' ? 'Chạm “Quản lý tin →”' : 'Chạm ✕ ở góc phải', 'Chuyển sang Quản lý tin (User Ad Dashboard)', 'Chạm ‹ để quay lại'],
    setup(st){ ixStep(0); st._listen = ev => { if (ev === 'qlt-open' || ev === 'dest-open') ixStep(2); if (ev === 'qlt-close' || ev === 'dest-close') ixStep(3, true); }; },
    async play(st){ await sleep(700); $('[data-act="close"], [data-act="manage"]', st).click(); await sleep(1600); const b = $('[data-qlt].open [data-act="qlt-back"], [data-dest].open [data-act="dest-back"]', st); if (b) b.click(); } }
];
let ixRun = 0;
function scrollToEl(st, el){
  const sc = $('.phone-scroll', st);
  if (sc && el){ const top = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop - 200; sc.scrollTop = Math.max(0, top); sc.dispatchEvent(new Event('scroll')); }
}
function ixStep(n, finished){
  $$('#ix-panel .steps li').forEach((li, i) => {
    li.classList.toggle('done', i < n || (!!finished && i <= n));
    li.classList.toggle('cur', !finished && i === n);
  });
}
const scenarioList = () => SCENARIOS.filter(s => s.devices.includes(device) && (!s.verticals || s.verticals.includes(ixVertical)));
function renderInteraction(){
  const list = scenarioList();
  if (!list.some(s => s.id === ixSel)) ixSel = list[0].id;
  const sc = SCENARIOS.find(s => s.id === ixSel);
  let groups = ''; let last = '';
  list.forEach(s => { if (s.group !== last){ groups += `<p class="ix-group">${s.group}</p>`; last = s.group; }
    groups += `<button class="ix-item${s.id === ixSel ? ' on' : ''}" data-ix="${s.id}"><b>${s.title}</b><span>${s.desc}</span></button>`; });
  $('#ix-panel').innerHTML = `<h2>Kịch bản tương tác</h2><p class="note">Bấm ▶ để tự chạy, hoặc tự thao tác trên màn — danh sách bước và log ECS cập nhật theo.</p>
    <div class="ctl"><label>Ngành hàng</label><div class="seg">${[['pty','Nhà Tốt (PTY)'],['job','Việc Làm Tốt (JOB)']].map(([v,t]) => `<button data-ixv="${v}" aria-pressed="${String(ixVertical === v)}">${t}</button>`).join('')}</div></div>
    <div class="ix-list">${groups}</div><div class="hr"></div>
    <ol class="steps">${sc.steps().map(t => `<li>${t}</li>`).join('')}</ol>
    <div class="ix-actions"><button class="primary" data-ixplay>▶ Tự chạy</button><button data-ixreset>↺ Làm lại</button></div>
    <div class="hr"></div><h2>Sự kiện ECS</h2><ul class="ecs" data-ecs></ul>`;
  overlayStack.length = 0;
  const st = mountStage($('#ix-stage'), sc.feed(ixVertical));
  sc.setup(st);
}
document.addEventListener('click', async e => {
  const b = e.target.closest('#ix-panel button'); if (!b) return;
  if (b.dataset.ix){ ixSel = b.dataset.ix; save(); renderInteraction(); }
  else if (b.dataset.ixv){ ixVertical = b.dataset.ixv; save(); renderInteraction(); }
  else if (b.hasAttribute('data-ixreset')){ ixRun++; renderInteraction(); }
  else if (b.hasAttribute('data-ixplay')){
    const run = ++ixRun; renderInteraction();
    const st = $('#ix-stage [data-stage]'); const sc = SCENARIOS.find(s => s.id === ixSel);
    $('#ix-panel [data-ixplay]').disabled = true;
    try { await sc.play(st); } finally { if (run === ixRun){ const btn = $('#ix-panel [data-ixplay]'); if (btn) btn.disabled = false; } }
  }
});

/* ═══ Variant board ═════════════════════════════════════════════════════════ */
function sectionOnly(sec, desktop){
  const o = Object.assign({}, DEFAULTS, { vertical:sec.vertical, desktop, status:'paid_fee' }, sec.props || {});
  if (sec.kind === 'voucher_list') return voucherListSection(o, 3);
  if (sec.kind === 'widget') return widgetSection(o);
  if (sec.kind === 'upsell') return upsellSection(o) || `<section class="sec ${o.vertical}"><p class="spec-note">Upsell block ẩn hoàn toàn — widget vẫn hiển thị (AC-EC-08).</p></section>`;
  if (sec.kind === 'labels') return ['popular','discount','none'].map(l => upsellSection(Object.assign({}, o, { label:l }))).join('');
  return '';
}
function cellHTML(c, desktop){
  let frame;
  if (c.image) frame = `<div class="bframe" style="width:373px">${img(c.image)}</div>`;
  else if (c.section) frame = desktop
    ? `<div class="bframe d" data-fit><div class="dscale"><div class="dpage" style="background:transparent"><div class="dcont" style="margin:0">${sectionOnly(c.section, true)}</div></div></div></div>`
    : `<div class="bframe" style="width:375px"><div class="scr">${sectionOnly(c.section, false)}</div></div>`;
  else if (desktop) frame = `<div class="bframe d" data-fit><div class="dscale">${screen(Object.assign({}, c.props, { desktop:true }))}</div></div>`;
  else if (c.frameH) frame = `<div class="bframe" style="width:375px;height:${c.frameH}px">${screen(c.props)}${overlay(Object.assign({}, DEFAULTS, c.props), true, true)}</div>`;
  else frame = `<div class="bframe" style="width:375px">${screen(c.props)}</div>`;
  const src = c.figma ? `Figma ${c.figma}` : '<span class="prd-only">Chỉ có trong PRD — Figma chưa có frame</span>';
  return `<div class="bcell" data-cell="${c.id}"${c.figma ? ` data-figma="${c.figma}"` : ''}><div class="cap"><b>${esc(c.label)}</b>${esc(c.rule || '')}<br>${src}${c.diff ? `<br><span class="diff">≠ ${esc(c.diff)}</span>` : ''}</div>${frame}</div>`;
}
function renderBoard(){
  [['board-m', false], ['board-d', true]].forEach(([id, desktop]) => {
    const groups = boardFor(desktop);
    $('#' + id).innerHTML = `<section class="prd-diff"><h2>PRD ↔ Figma — điểm cần cập nhật design</h2><ul>${PRD_DIFFS.map(d => `<li>${d}</li>`).join('')}</ul></section>`
      + groups.map(g => `<section class="bgroup" id="${g.id}"><h2>${g.title}</h2><p>${g.note || ''}</p><div class="brow">${g.cells.map(c => cellHTML(c, desktop)).join('')}</div></section>`).join('');
    $(`.board-nav[data-for="${desktop ? 'desktop' : 'mobile'}"]`).innerHTML = groups.map(g => `<a href="#${g.id}">${g.title.replace(/^(Mobile|Desktop) · /,'')}</a>`).join('');
  });
}
document.addEventListener('click', e => { const a = e.target.closest('.board-nav a'); if (a && mode !== 'board') setMode('board'); });

/* ═══ Sizing ════════════════════════════════════════════════════════════════ */
function fitPages(){
  $$('.dpage-wrap').forEach(w => {
    const pg = $('.dpage', w); if (!pg || !w.clientWidth) return;
    const k = Math.min(1, w.clientWidth / 1440);
    pg.style.transform = k < 1 ? `scale(${k})` : '';
    w.style.height = Math.ceil(pg.offsetHeight * k) + 'px';
  });
  $$('.phone').forEach(ph => {
    const w = ph.parentElement.clientWidth; if (!w) return;
    const k = Math.min(1, w / 395);
    ph.style.transform = k < 1 ? `scale(${k})` : '';
    ph.style.marginBottom = k < 1 ? `${-(1 - k) * 832}px` : '';
  });
  $$('.bframe[data-fit]').forEach(f => { const pg = $('.dscale', f); if (!f.clientWidth) return; f.style.height = Math.ceil(pg.firstElementChild.offsetHeight * .5) + 'px'; });
  document.documentElement.style.setProperty('--head-h', headH() + 'px');
}
new ResizeObserver(() => fitPages()).observe(document.body);

/* ═══ Mode + device ═════════════════════════════════════════════════════════ */
function setMode(m){
  mode = m;
  $('#playground').hidden = m !== 'screen'; $('#ix').hidden = m !== 'interaction'; $('#board').hidden = m !== 'board';
  document.body.classList.toggle('mode-board', m === 'board');
  $$('[data-mode]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mode === m)));
  $$('.board-nav').forEach(n => n.classList.toggle('on', n.dataset.for === device));
  save(); fitPages();
}
function setDevice(d){
  device = d;
  document.body.classList.toggle('device-desktop', d === 'desktop');
  $$('[data-device]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.device === d)));
  $('#device-label').textContent = d === 'desktop' ? '(Desktop)' : '(Mobile)';
  $('#board-m').hidden = d !== 'mobile'; $('#board-d').hidden = d !== 'desktop';
  $$('.board-nav').forEach(n => n.classList.toggle('on', n.dataset.for === d));
  overlayStack.length = 0; presetSel = null;
  renderPreview(); renderPanel(); renderInteraction();
  save(); fitPages();
}
$$('[data-mode]').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));
$$('[data-device]').forEach(b => b.addEventListener('click', () => setDevice(b.dataset.device)));

/* ?export=1 renders the canvas artboards (Claude Design) as static markup + measured heights, dumped as JSON */
const EXPORT_SPECS = [
  ['Main.dc.html','PTY · Thanh toán thành công','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', voucherCount:'3' }],
  ['PTY-Free-Voucher.dc.html','PTY · Đăng tin miễn phí','mpty',{ vertical:'pty', status:'free_voucher', card:'collapsed', ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', voucherCount:'1' }],
  ['PTY-Payment-Fail.dc.html','PTY · Thanh toán thất bại','mpty',{ vertical:'pty', status:'payment_fail' }],
  ['PTY-Bottomsheet.dc.html','PTY · Chọn số ngày Đẩy tin','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', voucherCount:'1' }, 'sheet'],
  ['PTY-Loading.dc.html','PTY · Đang tải — skeleton','mpty',{ vertical:'pty', status:'paid_fee', apiState:'loading' }],
  ['PTY-API-Error.dc.html','PTY · Lỗi gọi API — empty state','mpty',{ vertical:'pty', status:'paid_fee', apiState:'error' }],
  ['PTY-CrossPost.dc.html','PTY · Có tin Cross-Post (Retain, Professional)','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'retain', ptyTier:'professional', ptyCond:'xpost' }],
  ['PTY-Competitor.dc.html','PTY · Có tin competitor','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'competitor' }],
  ['PTY-Video.dc.html','PTY · Fallback — tin chưa có video','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'retain', ptyTier:'elite', ptyCond:'fb_video' }],
  ['PTY-Verify.dc.html','PTY · Fallback — xác thực Phòng 5 tốt','mpty',{ vertical:'pty', status:'paid_fee', ptySegment:'retain', ptyTier:'elite', ptyCond:'fb_verify' }],
  ['JOB-Paid-New-Vouchers.dc.html','JOB · New Listors — nhiều voucher (không có voucher đăng tin)','mjob',{ vertical:'job', status:'paid_fee', jobBucket:'new', jobPromo:'other_voucher', voucherCount:'3', label:'recommend' }],
  ['JOB-Paid-General.dc.html','JOB · General Listors — không promotion','mjob',{ vertical:'job', status:'paid_fee', jobBucket:'general', jobPromo:'none', label:'popular' }],
  ['JOB-Free-Voucher.dc.html','JOB · Đăng tin miễn phí — 1 voucher','mjob',{ vertical:'job', status:'free_voucher', card:'collapsed', jobBucket:'general', jobPromo:'free_listing', voucherCount:'1', label:'discount' }],
  ['JOB-Payment-Fail.dc.html','JOB · Thanh toán thất bại','mjob',{ vertical:'job', status:'payment_fail' }],
  ['JOB-Loading.dc.html','JOB · Đang tải — skeleton','mjob',{ vertical:'job', status:'paid_fee', apiState:'loading', label:'recommend' }],
  ['JOB-API-Error.dc.html','JOB · Lỗi gọi API — empty state','mjob',{ vertical:'job', status:'paid_fee', apiState:'error', label:'recommend' }],
  ['JOB-Bottomsheet.dc.html','JOB · Chọn số ngày Gói Tuyển Gấp','mjob',{ vertical:'job', status:'paid_fee', jobBucket:'general', jobPromo:'none', label:'recommend' }, 'sheet'],
  ['JOB-Tier1.dc.html','JOB · Tier 1 — ẩn upsell','mjob',{ vertical:'job', status:'paid_fee', jobBucket:'new', jobPromo:'none', jobTier:'t1' }],
  ['Desktop-PTY-Paid.dc.html','Desktop · PTY · Thanh toán thành công','desk',{ vertical:'pty', status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', voucherCount:'3' }],
  ['Desktop-JOB-Paid.dc.html','Desktop · JOB · General Listors','desk',{ vertical:'job', status:'paid_fee', jobBucket:'general', jobPromo:'none', label:'popular' }],
  ['Desktop-PTY-Fail.dc.html','Desktop · PTY · Thanh toán thất bại','desk',{ vertical:'pty', status:'payment_fail' }],
  ['Desktop-PTY-Dialog.dc.html','Desktop · PTY · Dialog chọn số ngày','desk',{ vertical:'pty', status:'paid_fee', ptySegment:'new', ptyTier:'casual', ptyCond:'voucher', voucherCount:'3' }, 'sheet']
];
if (new URLSearchParams(location.search).get('export')){
  document.body.innerHTML = '<div id="exp" style="position:absolute;left:0;top:0"></div>';
  document.body.style.background = '#fff';
  const host = document.getElementById('exp'); const out = [];
  EXPORT_SPECS.forEach(([file, title, page, props, ovl]) => {
    const desktop = page === 'desk';
    const o = Object.assign({}, DEFAULTS, props, { desktop, overlay: ovl && desktop ? 'sheet' : 'none', static:true });
    let html = screen(o);
    if (ovl && !desktop) html = `<div class="mframe">${html}${overlay(o, true, true)}</div>`;
    host.innerHTML = html;
    const el = host.firstElementChild;
    el.querySelectorAll('[data-toast]').forEach(t => t.remove());
    const w = desktop ? 1440 : 375;
    const h = ovl && !desktop ? 885 : Math.ceil(el.getBoundingClientRect().height);
    out.push({ file, title, page, w, h, html: el.outerHTML });
  });
  document.body.innerHTML = '<pre id="out"></pre>';
  document.getElementById('out').textContent = JSON.stringify(out);
  throw new Error('export');
}
/* ?solo=<cell id or figma node>&d=1 renders one board frame alone at 1:1 (used for screenshot checks against Figma) */
const solo = new URLSearchParams(location.search);
if (solo.get('solo')){
  const desktop = solo.get('d') === '1';
  const c = boardFor(desktop).flatMap(g => g.cells).find(x => x.figma === solo.get('solo') || x.id === solo.get('solo'));
  document.body.innerHTML = c ? cellHTML(c, desktop) : 'not found';
  document.body.style.background = '#fff';
  const cap = $('.cap'); if (cap) cap.remove();
  const f = $('.bframe.d'); if (f){ f.style.width = '1440px'; f.removeAttribute('data-fit'); $('.dscale', f).style.transform = 'none'; }
  throw new Error('solo');
}
load();
renderBoard();
setDevice(device);
setMode(location.hash ? 'board' : mode);
if (location.hash){ const t = document.getElementById(location.hash.slice(1)); if (t) t.scrollIntoView(); }
