# Handoff — VLT Ad Card (Mobile + Desktop)

**Đọc file này trước.** Spec chính: `designspec-vlt-ad-card.md`.

## Còn thiếu (chặn QC, không chặn build)
- ⚠️ **N1** Thumbnail mặc định theo ngành (tin không có logo/ảnh) — chưa có asset.
- ⚠️ **N2** Nội dung sheet/Drawer cho *cá nhân đã xác thực* — chưa có trong Figma.
- ⚠️ **N3** Label pill "Lưu" (Desktop) khi đã lưu.
- ⚠️ **N4** 6 icon cần DS confirm tên (bolt Gấp, chevron-up, icon "Tuyển nhanh hơn", Person, Sort, Grid).
- ⚠️ **N5** Token DS cho các màu / size chữ đang giữ raw theo Figma.
- ⚠️ **N6** Error state khi lưu tin thất bại — NOT DESIGNED.
- ⚠️ **N7** Event tracking cho interaction mới.
Không có mục 🔴 blocking.

## Gói có gì
| Thư mục | Nội dung |
|---|---|
| `designspec-vlt-ad-card.md` | Spec đầy đủ (layout YAML, token, content rule, edge case, animation 4 platform) |
| `assets/icons/` | 27 icon SVG/PNG đã đổi tên có nghĩa; `_map.json` = tên prototype ↔ tên gói ↔ tên DS. Ưu tiên icon DS của platform, SVG để đối chiếu |
| `assets/demo/` | Ảnh mẫu (ảnh tin, logo, avatar, SDA) — **không phải asset production**, dữ liệu thật đến từ API |
| `prototype/job-adlisting/index.html` | Prototype chạy offline (mở trực tiếp bằng Chrome) — nguồn chân lý cho animation & tương tác |
| `prototype/vlt-ad-card-single-file.html` | Bản 1 file (asset nhúng sẵn) — giống bản trên Builder OS |

## Cách xem prototype
Mở `prototype/job-adlisting/index.html` → chọn **📱 Mobile / 🖥 Desktop**, rồi tab **Screen preview** (chỉnh biến thể), **Interaction** (chạy flow), **Bảng biến thể** (toàn bộ variant theo Figma).
Live: https://arts.builderos.space/d/b3cafe1f85354ee31a4d2f76ddb14a0ce2de6b7a5fb7b3550348d742e18d9085/vlt-ad-card-mobile.html

Design owner: Thảo Dương · PRD: DSW-1647 · 2026-10-01 · cập nhật 2026-10-05 (xem Changelog trong spec)
